<?php include __DIR__ . '/snippets/header.php' ?>

  <p class="notice">
    This page is currently offline. We are very sorry for the inconvenience and will fix it as soon as possible.
  </p>
  <p class="admin-advice">
    Advice for developers and administrators:<br>
    Change the PHP version to one supported by your version of Kirby
  </p>

<?php include __DIR__ . '/snippets/footer.php' ?>
