<?php

return [
	'hidden' => true
];
