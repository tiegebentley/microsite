<?php

return [
	'save' => false,
	'props' => [
		/**
		 * Unset inherited props
		 */
		'after'       => null,
		'autofocus'   => null,
		'before'      => null,
		'default'     => null,
		'disabled'    => null,
		'icon'        => null,
		'placeholder' => null,
		'required'    => null,
		'translate'   => null
	]
];
