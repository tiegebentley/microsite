<?php

require 'kirby/bootstrap.php';

echo (new Kirby)->render();
