<?php

return [
    'pages' => [
        'active' => (bool) getenv('PAGE_CACHE_ENABLED'),
    ],
];
